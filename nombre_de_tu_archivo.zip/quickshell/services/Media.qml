pragma Singleton

import Quickshell
import QtQuick
import Quickshell.Services.Mpris

Singleton {
    id: root

    // ───────── Reproductor activo ─────────
    property alias activePlayer: instance.activePlayer

    // Alias cómodo estilo "archivo 2"
    readonly property var player: activePlayer

    readonly property bool isPlaying: activePlayer
        ? activePlayer.playbackState === MprisPlaybackState.Playing
        : false
    // Alias de compatibilidad
    readonly property bool playing: isPlaying

    // ───────── Metadatos ─────────
    property string title:   activePlayer ? activePlayer.trackTitle  : "No Media"
    property string artist:  activePlayer ? activePlayer.trackArtist : ""
    property string album:   activePlayer ? activePlayer.trackAlbum  : ""
    property string artUrl:  activePlayer ? activePlayer.trackArtUrl : ""

    // Cadena multilínea estilo archivo 2
    readonly property string track: activePlayer
        ? `${activePlayer.trackArtist}\n${activePlayer.trackTitle}` : ""

    // ───────── Posición / duración ─────────
    property double position: 0
    property double length: activePlayer ? activePlayer.length : 0

    // ───────── Track ID (Spotify) ─────────
    property string trackId

    readonly property var spotifyPlayer: Mpris.players.values.find(
        p => /(^|\.)spotify(\.|$)/.test(p.dbusName)) ?? null

    function spotifyTrackId() {
        const raw = root.spotifyPlayer && root.spotifyPlayer.metadata
            ? String(root.spotifyPlayer.metadata["mpris:trackid"] || "") : "";
        return raw.split("/").pop();
    }

    // ───────── Lista de reproductores ─────────
    property var _players: Mpris.players.values
    property alias players: root._players
    property int playerCount: _players.length

    property string currentPlayerName:
        activePlayer ? (activePlayer.identity || activePlayer.desktopEntry || "Unknown") : ""

    property bool manualSelection: false

    // ───────── Controles ─────────
    function setPosition(pos) {
        if (activePlayer)
            activePlayer.position = pos;
    }

    function playPause() {
        if (activePlayer && activePlayer.canTogglePlaying)
            activePlayer.togglePlaying();
    }

    function next() {
        if (activePlayer && activePlayer.canGoNext)
            activePlayer.next();
    }

    function previous() {
        if (activePlayer && activePlayer.canGoPrevious)
            activePlayer.previous();
    }

    function selectPlayer(player) {
        if (player) {
            instance.activePlayer = player;
            manualSelection = true;
        }
    }

    function nextPlayer() {
        const players = Mpris.players.values;
        if (players.length <= 1) return;
        const idx = players.indexOf(instance.activePlayer);
        selectPlayer(players[(idx + 1) % players.length]);
    }

    function previousPlayer() {
        const players = Mpris.players.values;
        if (players.length <= 1) return;
        const idx = players.indexOf(instance.activePlayer);
        selectPlayer(players[(idx - 1 + players.length) % players.length]);
    }

    // ───────── Utilidades ─────────
    function time(s) {
        s = Math.max(0, Math.floor(s || 0));
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
    }

    function updateActivePlayer() {
        const players = Mpris.players.values;

        if (manualSelection && instance.activePlayer && players.includes(instance.activePlayer))
            return;

        if (manualSelection && instance.activePlayer && !players.includes(instance.activePlayer))
            manualSelection = false;

        const playing = players.find(p => p.playbackState === MprisPlaybackState.Playing);

        if (playing) {
            instance.activePlayer = playing;
        } else if (players.length > 0) {
            if (!instance.activePlayer || !players.includes(instance.activePlayer))
                instance.activePlayer = players[0];
        } else {
            instance.activePlayer = null;
        }
    }

    Component.onCompleted: updateActivePlayer()

    // Resetear posición al cambiar de track (estilo archivo 2)
    onTrackChanged: position = activePlayer?.position ?? 0

    QtObject {
        id: instance
        property var activePlayer: null
    }

    // ───────── Polling ─────────
    // 500 ms mientras reproduce (barra de progreso suave),
    // 1000 ms en pausa (suficiente para detectar cambios de player).
    Timer {
        interval: root.isPlaying ? 500 : 1000
        running: true
        repeat: true

        onTriggered: {
            updateActivePlayer();

            if (activePlayer)
                root.position = activePlayer.position;

            const id = root.spotifyTrackId();
            if (id && root.trackId !== id) {
                root.trackId = id;
                console.log("Track ID:", id);
            }
        }
    }

    // ───────── Cambios en la lista de players ─────────
    Connections {
        target: Mpris.players

        function onValuesChanged() {
            root._players = Mpris.players.values;
            updateActivePlayer();
        }
    }
}
